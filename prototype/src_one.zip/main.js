'use strict'

const electron = require('electron')
const app = electron.app
const BrowserWindow = electron.BrowserWindow
const Menu = electron.Menu
const MenuItem = electron.MenuItem
const ipcMain = electron.ipcMain

const xlsx = require('node-xlsx')

let CARTEIRINHAS_MAIN

function processExcel (event, file) {
	var workSheetsFromFile = xlsx.parse(file)
	var length = workSheetsFromFile[0].data.length
	var data = workSheetsFromFile[0].data
	var alunos = []

	for (var i = 4; i < length; i++) {
		var aluno = {
			nome: data[i][2],
			nascimento: data[i][3],
			cpf: data[i][4],
			codigoDoAluno: data[i][5],
			validade: data[i][6],
			cidadeUnidade: data[i][7],
			curso: data[i][8]
		}
		//var aluno = data[i]
		alunos.push(aluno)
	}

	CARTEIRINHAS_MAIN.webContents.send('excelProcessed', alunos)
}

function createWindow () {
	CARTEIRINHAS_MAIN = new BrowserWindow({
		width: 465,
		height: 415,
		minWidth: 465,
		minHeight: 415
	})
	CARTEIRINHAS_MAIN.setMenu(null)
	CARTEIRINHAS_MAIN.loadURL('file://' + __dirname + '/index.html')
	//CARTEIRINHAS_MAIN.webContents.openDevTools()
	//CARTEIRINHAS_MAIN.webContents.send('alunos', getAlunos())
	ipcMain.on('processExcel', processExcel)
	CARTEIRINHAS_MAIN.on('closed', function() {
		CARTEIRINHAS_MAIN = null
	})
}

app.on('ready', createWindow)

app.on('window-all-closed', function () {
	if (process.platform !== 'darwin') {
		app.quit()
	}
})

app.on('activate', function () {
	if (CARTEIRINHAS_MAIN === null) {
		createWindow()
	}
})
