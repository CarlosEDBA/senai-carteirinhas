var Imprimir = Carteirinhas.prototype.Imprimir
var Utils = Carteirinhas.prototype.Utils
var Data = Carteirinhas.prototype.Data


Imprimir.window = remote.getCurrentWindow()

Imprimir.init = function () {
	//Utils.devTools()
	this.setButtons()
	Data.refresh()
	this.generateCarteirinhas()

	return this
}

Imprimir.createCarteirinha = function (aluno, ind) {
	var directory = Data.Photos.Directory
	var carteirinhas = document.querySelector('.carteirinhas');
	var carteirinha = document.createElement('div')
	carteirinha.setAttribute('class', 'carteirinha')

	var div = document.createElement('div')
	div.setAttribute('class', 'foto')
	div.style.backgroundImage = "url('file:///" + directory.replace(/\\/g,"/") + "/" + aluno.codigoDoAluno + ".jpg"
	carteirinha.appendChild(div)

	var dados = document.createElement('div')
	dados.setAttribute('class', 'dados')

	var span = document.createElement('span')
	span.setAttribute('class', 'nome')
	span.innerHTML = aluno.nome
	dados.appendChild(span)

	var span = document.createElement('span')
	span.setAttribute('class', 'input curso')
	span.innerHTML = aluno.curso
	dados.appendChild(span)

	var div = document.createElement('div')
	div.setAttribute('class', 'multi-input')

	var span = document.createElement('span')
	span.setAttribute('class', 'input nascimento')
	span.innerHTML = aluno.nascimento
	div.appendChild(span)

	var span = document.createElement('span')
	span.setAttribute('class', 'input cpf')
	span.innerHTML = aluno.cpf
	div.appendChild(span)

	dados.appendChild(div)

	var div = document.createElement('div')
	div.setAttribute('class', 'multi-input')

	var span = document.createElement('span')
	span.setAttribute('class', 'input instituicao')
	span.innerHTML = 'SENAI'
	div.appendChild(span)

	var span = document.createElement('span')
	span.setAttribute('class', 'input codigoDoAluno')
	span.innerHTML = aluno.codigoDoAluno
	div.appendChild(span)

	dados.appendChild(div)

	var div = document.createElement('div')
	div.setAttribute('class', 'multi-input')

	var span = document.createElement('span')
	span.setAttribute('class', 'input cidadeUnidade')
	span.innerHTML = aluno.cidadeUnidade
	div.appendChild(span)

	var span = document.createElement('span')
	span.setAttribute('class', 'input validade')
	span.innerHTML = aluno.validade
	div.appendChild(span)

	dados.appendChild(div)

	var canvas = document.createElement('canvas')
	canvas.setAttribute('class', 'barcode')
	JsBarcode(canvas, aluno.codigoDoAluno, {
		width: 25,
		height: 500,
		textAlign: 'center',
		textPosition: 'bottom',
		textMargin: 2,
		fontSize: 125,
		margin: 10
	})

	carteirinha.appendChild(canvas)
	carteirinha.appendChild(dados)
	carteirinhas.appendChild(carteirinha)
}

Imprimir.generateCarteirinhas = function () {
	;[].forEach.call(Data.Excel.Content, function (obj, ind, arr) {
		this.createCarteirinha(obj, ind)
	}.bind(this))
}

Imprimir.setButtons = function () {
	var btnImprimir = document.querySelector('.btn-imprimir');

	btnImprimir.addEventListener('click', this.print.bind(this))
}

Imprimir.print = function (e) {
	this.window.webContents.print({
		silent: false,
		printBackground: true
	})
}
